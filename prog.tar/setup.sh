ulimit -s unlimited
export OMP_STACKSIZE=100g
export OMP_NUM_THREADS=36
